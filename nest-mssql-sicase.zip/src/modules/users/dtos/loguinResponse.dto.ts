export class LoguinResponse {
  token: string;
  userId: string;
  isMfaEnabled: boolean;
  profileId: string;
  isNewUser: boolean;
}
